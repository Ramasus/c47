# Globo aerostático etapa 3
## Enlace de referencia 1 para la clase PROC47V2.
  
18-01-2022  
También usado en PROC52 1:4 Referencia de la maestra 1.  
Globo aerostático III
